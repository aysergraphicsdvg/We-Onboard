<?php
$rootCandidates = [__DIR__, dirname(__DIR__), dirname(__DIR__, 2)];
$root = '';
foreach ($rootCandidates as $cand) {
    if (file_exists($cand . '/config/config.php')) {
        $root = $cand;
        break;
    }
}

$settings = [];
if ($root) {
    require_once $root . '/config/config.php';
    if (file_exists($root . '/config/database.php')) {
        require_once $root . '/config/database.php';
        try {
            $db = Database::getConnection();
            $settingsRows = $db->query("SELECT setting_key, setting_value FROM site_settings")->fetchAll();
            foreach ($settingsRows as $r) {
                $settings[$r['setting_key']] = $r['setting_value'];
            }
        } catch (Exception $e) {
            error_log("Site settings query notice: " . $e->getMessage());
        }
    }
}

$phone = $settings['phone'] ?? '+91 96111 09490';
$email = $settings['email'] ?? 'mail@weonboard.in';
$headerLogo = $settings['headerLogoUrl'] ?? '';
$footerLogo = $settings['footerLogoUrl'] ?? '';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>We Onboard &mdash; Your Ground Engine for Growth</title>
  <meta name="description" content="We Onboard: rider and gig worker onboarding, merchant acquisition, field audits, franchise development and government MSME desk in Bangalore.">
  <link rel="stylesheet" href="/assets/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <style>
    body { font-family: Inter, sans-serif; color: #1e293b; margin: 0; }
    .topbar { background: #02167F; color: #fff; font-size: 12px; padding: 8px 16px; border-bottom: 1px solid rgba(255,255,255,0.1); }
    .topbar .container { max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; }
    .header { background: #fff; border-bottom: 1px solid #f1f5f9; position: sticky; top: 0; z-index: 40; }
    .header .container { max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; height: 75px; padding: 0 16px; }
    .brand { display: flex; align-items: center; text-decoration: none; }
    .brand-box { background: #FFD014; color: #02167F; font-weight: 900; font-size: 20px; padding: 4px 8px; border-radius: 6px; }
    .brand-name { color: #02167F; font-weight: 800; font-size: 22px; margin-left: 4px; }
    .nav { display: flex; gap: 20px; font-size: 14px; font-weight: 600; }
    .nav a { color: #334155; text-decoration: none; }
    .nav a:hover { color: #02167F; }
    .hero { background: #02167F; color: #fff; padding: 80px 20px; text-align: center; }
    .hero h1 { font-size: 42px; font-weight: 900; margin: 0 0 16px; line-height: 1.2; }
    .hero p { font-size: 18px; max-width: 700px; margin: 0 auto 30px; color: #cbd5e1; }
    .btn-gold { background: #FFD014; color: #02167F; font-weight: 800; padding: 14px 28px; border-radius: 8px; text-decoration: none; display: inline-block; }
    .section { max-width: 1200px; margin: 60px auto; padding: 0 20px; }
    .footer { background: #010e54; color: #fff; padding: 60px 20px 30px; margin-top: 80px; }
  </style>
</head>
<body>
  <!-- Top Details Bar -->
  <div class="topbar">
    <div class="container">
      <div>
        <span>☎ <?= htmlspecialchars($phone) ?></span> &nbsp;|&nbsp;
        <span>✉ <?= htmlspecialchars($email) ?></span> &nbsp;|&nbsp;
        <span>⌖ Indiranagar, Bangalore</span>
      </div>
      <div>
        <a href="#contact" style="color: #FFD014; font-weight: 700; text-decoration: none;">Request a Free Pilot Plan &rarr;</a>
      </div>
    </div>
  </div>

  <!-- Sticky Header -->
  <header class="header">
    <div class="container">
      <a href="/" class="brand">
        <?php if ($headerLogo): ?>
          <img src="<?= htmlspecialchars($headerLogo) ?>" alt="We Onboard" style="height: 44px; object-contain: fit;">
        <?php else: ?>
          <span class="brand-box">we</span><span class="brand-name">nboard</span>
        <?php endif; ?>
      </a>
      <nav class="nav">
        <a href="#services">Services</a>
        <a href="#businesses">For Businesses</a>
        <a href="/join-as-freelancer.php">Join as Freelancer</a>
        <a href="#msme">Govt & MSME Desk</a>
        <a href="#about">About</a>
        <a href="#contact">Contact</a>
      </nav>
    </div>
  </header>

  <!-- Hero Section -->
  <section class="hero">
    <div style="font-size: 12px; font-weight: 800; color: #FFD014; text-transform: uppercase; margin-bottom: 12px; letter-spacing: 1px;">BANGALORE ON-GROUND EXECUTION ENGINE</div>
    <h1>Your ground engine for growth.</h1>
    <p>We onboard the riders, workers, shops, restaurants and field operations your enterprise needs, verified, trained and ready to scale.</p>
    <div>
      <a href="#contact" class="btn-gold">Request Free Pilot Plan &rarr;</a>
      <a href="/join-as-freelancer.php" style="color: #fff; font-weight: 700; margin-left: 16px; text-decoration: underline;">Join as Freelancer</a>
    </div>
  </section>

  <!-- About Section -->
  <section class="section" id="about">
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 16px; padding: 40px;">
      <h2 style="color: #02167F; font-size: 28px; margin-top: 0;">Growth happens <em>on the ground.</em></h2>
      <p style="font-size: 16px; line-height: 1.6; color: #475569;">
        Founded by <strong>Muhammd Ali Shoaib</strong> and <strong>Umme Morsi</strong>, 
        <strong>We Onboard</strong> bridges high-growth consumer technology platforms, retail chains, and expanding enterprises with the physical ground capabilities they need to scale across South India.
      </p>
      <p style="font-size: 14px; color: #64748b;">Headquartered in Indiranagar, Bangalore with zero joining fees for job seekers and freelancers.</p>
    </div>
  </section>

  <!-- Contact Form Section -->
  <section class="section" id="contact">
    <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 16px; padding: 40px; box-shadow: 0 4px 20px rgba(0,0,0,0.05);">
      <h2 style="color: #02167F; font-size: 24px; margin-top: 0;">Start a Pilot with We Onboard</h2>
      <p style="color: #64748b; font-size: 14px;">Submit your business requirements or enquiry and our team will prepare a structured pilot scope.</p>
      <form action="/api/enquiry.php" method="POST" style="margin-top: 20px;">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
          <div>
            <label style="display: block; font-size: 13px; font-weight: 700; margin-bottom: 4px;">Full Name *</label>
            <input type="text" name="full_name" required style="width: 100%; box-sizing: border-box; padding: 10px; border: 1px solid #cbd5e1; border-radius: 8px;">
          </div>
          <div>
            <label style="display: block; font-size: 13px; font-weight: 700; margin-bottom: 4px;">Contact Phone *</label>
            <input type="tel" name="phone" required style="width: 100%; box-sizing: border-box; padding: 10px; border: 1px solid #cbd5e1; border-radius: 8px;">
          </div>
        </div>
        <div style="margin-top: 16px;">
          <label style="display: block; font-size: 13px; font-weight: 700; margin-bottom: 4px;">Email Address</label>
          <input type="email" name="email" style="width: 100%; box-sizing: border-box; padding: 10px; border: 1px solid #cbd5e1; border-radius: 8px;">
        </div>
        <div style="margin-top: 16px;">
          <label style="display: block; font-size: 13px; font-weight: 700; margin-bottom: 4px;">Scope Details / Message</label>
          <textarea name="message" rows="3" style="width: 100%; box-sizing: border-box; padding: 10px; border: 1px solid #cbd5e1; border-radius: 8px;"></textarea>
        </div>
        <button type="submit" class="btn-gold" style="border: none; margin-top: 20px; cursor: pointer;">Submit Request &rarr;</button>
      </form>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
    <div style="max-width: 1200px; margin: 0 auto; text-align: center; font-size: 13px; color: #94a3b8;">
      <p style="color: #fff; font-weight: 700; font-size: 16px;">We Onboard &mdash; Your Ground Engine for Growth</p>
      <p>Indiranagar, Bangalore &bull; <?= htmlspecialchars($phone) ?> &bull; <?= htmlspecialchars($email) ?></p>
      <p style="margin-top: 20px;">&copy; <?= date('Y') ?> We Onboard. All rights reserved.</p>
    </div>
  </footer>
</body>
</html>
