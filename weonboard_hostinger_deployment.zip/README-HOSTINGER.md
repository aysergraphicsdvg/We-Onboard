# We Onboard Deployment Guide — Hostinger Business Shared Hosting

## Quick Start (5 Steps)

### Step 1: Upload Files
1. Log into your Hostinger hPanel.
2. Go to **File Manager** -> Open **`public_html`**.
3. Upload all files and folders from this zip package directly into `public_html`.

### Step 2: Configure API Subdomain Routing in Hostinger
1. In hPanel, navigate to **Domains** -> **Subdomains**.
2. For subdomain **`api.weonboard.in`**, configure the custom folder / document root to **`public_html/api`**.
3. Under this configuration:
   - Root URL `https://api.weonboard.in/v1/health.php` resolves directly to `public_html/api/v1/health.php`.
   - The provided `api/.htaccess` includes rewrite rules to ensure both `/v1/*` and legacy `/api/v1/*` work seamlessly without `/api/api/` duplication.

### Step 3: Create MySQL Database & Import Schema
1. In hPanel, go to **Databases** -> **MySQL Databases**.
2. Create a new database (e.g. `u123456789_weonboard`).
3. Create a database user with ALL privileges.
4. Open **phpMyAdmin** for that database.
5. Click **Import** -> Select `database/schema.sql` from this package -> Click **Go**.
   - All 17 tables, indexes, constraints, and initial roles will be imported cleanly.

### Step 4: Configure Database Credentials
Edit `config/config.php`:
- `DB_HOST`: `localhost`
- `DB_NAME`: your database name
- `DB_USER`: your database username
- `DB_PASS`: your database password

### Step 5: Provision Initial Super Admin
You can provision the administrator account using either method:
- **Primary & Recommended (CLI via SSH):**
  Connect via Hostinger SSH terminal and run:
  ```bash
  php scripts/create_super_admin.php "Muhammad Ali Shoaib" "admin@weonboard.in" "YourSecurePassword"
  ```
  Then immediately lock or remove the web installer:
  ```bash
  touch config/install.lock
  # or: rm install.php
  ```
- **Alternate (One-Time Web Installer):**
  Navigate to `https://weonboard.in/install.php` in your browser. Enter your database credentials and specify a secure administrator password (&gt;= 8 characters). Upon successful submission, the installer automatically writes `config/install.lock`, permanently preventing subsequent web access.

### Step 6: Verify Deployment & Automated Smoke Tests
1. Test API health probe:
   ```bash
   curl -i https://api.weonboard.in/v1/health.php
   ```
   Expected response (HTTP 200):
   ```json
   {"status":"healthy","service":"weonboard-api","version":"1.0.0","database":"available"}
   ```
2. Run the included automated shell smoke test:
   ```bash
   chmod +x scripts/hostinger_smoke_test.sh
   ./scripts/hostinger_smoke_test.sh
   ```

## Security & Architecture Hardening
- **PHP Version**: PHP 8.2+ with PDO enabled.
- **SSL**: Active for both `weonboard.in` and `api.weonboard.in`.
- **Prepared Statements**: 100% PDO prepared statements across all endpoints.
- **Brute Force Protection**: Rate-limited admin login (5 attempts max / 15 minutes) via `login_attempts` table.
- **Session Security**: `HttpOnly`, `SameSite=Lax`, `session_regenerate_id(true)` on login.
- **Audit Logging**: Every inbound enquiry, freelancer registration, MSME proposal, and login attempt is recorded in `audit_logs`.
- **Directory Protection**: Sensitive directories (`config/`, `database/`, `scripts/`, `logs/`) return HTTP 403 Forbidden via Apache rewrite rules.
