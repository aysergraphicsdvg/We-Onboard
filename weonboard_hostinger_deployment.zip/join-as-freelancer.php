<?php
$rootCandidates = [__DIR__, dirname(__DIR__), dirname(__DIR__, 2)];
$root = '';
foreach ($rootCandidates as $cand) {
    if (file_exists($cand . '/config/config.php')) {
        $root = $cand;
        break;
    }
}
if (!$root) {
    die("System configuration error: config/config.php not found. Please verify deployment paths.");
}
require_once $root . '/config/config.php';
require_once $root . '/config/database.php';

$success = '';
$error = '';
$newRef = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $fullName = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $dob = trim($_POST['dob'] ?? '2000-01-01');
    $city = trim($_POST['city'] ?? 'Bengaluru');
    $state = trim($_POST['state'] ?? 'Karnataka');
    $pin = trim($_POST['pin_code'] ?? '560038');
    $address = trim($_POST['address'] ?? '');
    $role = trim($_POST['preferred_role'] ?? 'Field Executive / Team Member');
    $workType = trim($_POST['work_type'] ?? 'Full-time');
    $skills = trim($_POST['skills'] ?? 'Field Onboarding');

    if (empty($fullName) || empty($phone) || empty($email)) {
        $error = 'Please fill all mandatory fields (Name, Phone, Email).';
    } else {
        $cleanPhone = preg_replace('/[^d+]/', '', $phone);
        $cleanEmail = strtolower($email);
        try {
            $db = Database::getConnection();

            // Check duplicate (strict privacy: never leak existing registration_ref)
            $check = $db->prepare("SELECT id FROM freelancers WHERE phone = ? OR email = ? LIMIT 1");
            $check->execute([$cleanPhone, $cleanEmail]);
            $existing = $check->fetch();

            if ($existing) {
                $error = "An application with this mobile number or email address has already been submitted. Our operations team reviews all applications within 24-48 hours.";
            } else {
                $newRef = 'WO-FR-' . date('Y') . '-' . str_pad((string)rand(100, 9999), 4, '0', STR_PAD_LEFT);

                $stmt = $db->prepare("INSERT INTO freelancers 
                    (registration_ref, full_name, email, phone, dob, residential_address, city, state, pin_code, is_adult, has_smartphone, languages, preferred_areas, preferred_work_type, education, skills, preferred_role, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 'Kannada, English', 'Indiranagar', ?, '12th Pass', ?, ?, 'Submitted')");
                $stmt->execute([$newRef, $fullName, $cleanEmail, $cleanPhone, $dob, $address ?: 'Bangalore', $city, $state, $pin, $workType, $skills, $role]);

                $success = "Registration received successfully! Your Reference ID is " . $newRef;
            }
        } catch (Exception $e) {
            error_log("Freelancer registration form error: " . $e->getMessage());
            $error = "Unable to complete registration at this time. Please contact us directly at mail@weonboard.in.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Join as Freelancer &mdash; We Onboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { font-family: Inter, sans-serif; background: #f8fafc; margin: 0; padding: 40px 20px; }
    .box { max-width: 650px; margin: 0 auto; background: #fff; padding: 36px; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.06); border: 1px solid #e2e8f0; }
    h1 { color: #02167F; margin-top: 0; }
    label { display: block; font-size: 13px; font-weight: 700; margin: 12px 0 4px; }
    input, select, textarea { width: 100%; box-sizing: border-box; padding: 10px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 14px; }
    .btn { background: #FFD014; color: #02167F; font-weight: 800; border: none; padding: 14px; border-radius: 8px; font-size: 15px; cursor: pointer; width: 100%; margin-top: 20px; }
  </style>
</head>
<body>
  <div class="box">
    <div style="background: #02167F; color: #FFD014; font-size: 11px; font-weight: 800; display: inline-block; padding: 4px 8px; border-radius: 4px; margin-bottom: 12px;">ZERO CANDIDATE FEES</div>
    <h1>Join We Onboard Field Associate Network</h1>
    <p style="color: #64748b; font-size: 14px;">Earn transparent, weekly payouts for verified merchant acquisitions, rider onboarding, and survey drives across South India.</p>

    <?php if ($success): ?>
      <div style="background: #dcfce7; color: #166534; padding: 20px; border-radius: 8px; text-align: center;">
        <h2 style="margin: 0 0 10px;">Registration Submitted!</h2>
        <p><?= htmlspecialchars($success) ?></p>
        <p style="font-size: 13px;">Our operations coordinator in Indiranagar will review your profile within 24-48 hours.</p>
        <a href="/" style="display: inline-block; margin-top: 14px; color: #02167F; font-weight: 700;">&larr; Return to Homepage</a>
      </div>
    <?php else: ?>
      <?php if ($error): ?><div style="color: #b91c1c; background: #fee2e2; padding: 10px; border-radius: 6px;"><?= htmlspecialchars($error) ?></div><?php endif; ?>
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        <label>Full Legal Name (as on Aadhaar)</label>
        <input type="text" name="full_name" required placeholder="e.g. Rahul Sharma">
        <label>Mobile Number</label>
        <input type="tel" name="phone" required placeholder="+91 98450 XXXXX">
        <label>Email Address</label>
        <input type="email" name="email" required placeholder="rahul@example.com">
        <label>Preferred Role</label>
        <select name="preferred_role">
          <option>Field Executive / Team Member</option>
          <option>Team Leader</option>
          <option>Project Manager</option>
          <option>Independent Freelancer</option>
        </select>
        <label>City / Hub</label>
        <input type="text" name="city" value="Bengaluru" required>
        <label>Residential Address</label>
        <textarea name="address" rows="2" placeholder="Street, Layout, Area"></textarea>
        <button type="submit" class="btn">Submit Registration &rarr;</button>
      </form>
      <div style="text-align: center; margin-top: 20px;">
        <a href="/" style="color: #64748b; font-size: 13px; text-decoration: none;">&larr; Back to We Onboard Website</a>
      </div>
    <?php endif; ?>
  </div>
</body>
</html>
